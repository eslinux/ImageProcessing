#include "QVideoDevice.h"

QVideoDevice::QVideoDevice(QObject *parent, QString _devName) :
    QObject(parent)
{
    this->m_strDeviceName = _devName;
    this->m_fd = -1;
}

// Open video device
int QVideoDevice::openDevice(QString strDevName)
{
    this->m_strDeviceName = strDevName;
    this->m_fd = open(this->m_strDeviceName.toStdString().c_str(), O_RDWR, 0);

    // Open error
    if (this->m_fd == -1)
    {
        return -1;
    }
    return 0;
}

// Close video device
int QVideoDevice::closeDevice()
{
    // Close error
    if (close(this->m_fd) == -1)
    {
        return -1;
    }
    return 0;
}

// Init video device
int QVideoDevice::initDevice()
{
    v4l2_capability o_cap;
    v4l2_cropcap o_cropcap;
    v4l2_crop o_crop;
    v4l2_format o_fmt;
    unsigned int o_min;

    if (ioctl(this->m_fd, VIDIOC_QUERYCAP, &o_cap))
    {
        return -1;
    }

    if (!(o_cap.capabilities & V4L2_CAP_VIDEO_CAPTURE))
    {
        return -1;
    }

    if (!(o_cap.capabilities & V4L2_CAP_STREAMING))
    {
        return -1;
    }

    CLEAR(o_cropcap);

    o_cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(this->m_fd, VIDIOC_CROPCAP, &o_cropcap) == 0)
    {
        CLEAR(o_cropcap);
        o_cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

        if (ioctl(this->m_fd, VIDIOC_CROPCAP, &o_cropcap) == 0)
        {
            CLEAR(o_cropcap);
            o_crop.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            o_crop.c = o_cropcap.defrect;

            if (ioctl(this->m_fd, VIDIOC_S_CROP, &o_crop) == 0)
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }

    CLEAR(o_fmt);

    o_fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    // Camera format YUYV
    o_fmt.fmt.pix.width = CAMERA_FRAME_WIDTH;
    o_fmt.fmt.pix.height = CAMERA_FRAME_HEIGHT;
    //o_fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
    o_fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG;
    o_fmt.fmt.pix.field = V4L2_FIELD_ANY;

    if (ioctl(this->m_fd, VIDIOC_S_FMT, &o_fmt) == -1)
    {
        return -1;
    }
    // Buggy driver paranoia
    o_min = o_fmt.fmt.pix.width * 2;
    if (o_fmt.fmt.pix.bytesperline < o_min)
        o_fmt.fmt.pix.bytesperline = o_min;
    o_min = o_fmt.fmt.pix.bytesperline * o_fmt.fmt.pix.height;
    if (o_fmt.fmt.pix.sizeimage < o_min)
        o_fmt.fmt.pix.sizeimage = o_min;

    if (initMMap() == -1)
        return -1;
    return 0;
}

int QVideoDevice::initMMap()
{
    v4l2_requestbuffers o_req;
    CLEAR(o_req);

    o_req.count = 4;
    o_req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    o_req.memory = V4L2_MEMORY_MMAP;

    if (ioctl(this->m_fd, VIDIOC_REQBUFS, &o_req))
    {
        return -1;
    }

    if (o_req.count < 2)
    {
        return -1;
    }

    this->m_myBuffers = (myBufferVideo*)calloc(o_req.count, sizeof(*this->m_myBuffers));

    if (!this->m_myBuffers)
    {
        return -1;
    }

    for (this->m_nBuffers = 0 ; this->m_nBuffers < o_req.count ; this->m_nBuffers++)
    {
        v4l2_buffer o_buf;
        CLEAR(o_buf);

        o_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        o_buf.memory = V4L2_MEMORY_MMAP;
        o_buf.index = this->m_nBuffers;

        if (ioctl(this->m_fd, VIDIOC_QUERYBUF, &o_buf))
        {
            return -1;
        }

        this->m_myBuffers[this->m_nBuffers].length = o_buf.length;
        this->m_myBuffers[this->m_nBuffers].pStart = mmap(NULL,
                                                          o_buf.length,
                                                          PROT_READ | PROT_WRITE,
                                                          MAP_SHARED,
                                                          this->m_fd,
                                                          o_buf.m.offset);
        if (this->m_myBuffers[this->m_nBuffers].pStart == MAP_FAILED)
        {
            return -1;
        }
    }
    return 0;

}

int QVideoDevice::startCapturing()
{
    for (unsigned int i = 0 ; i < this->m_nBuffers ; i++)
    {
        v4l2_buffer o_buf;
        CLEAR(o_buf);

        o_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        o_buf.memory = V4L2_MEMORY_MMAP;
        o_buf.index = i;

        if (ioctl(this->m_fd, VIDIOC_QBUF, &o_buf))
        {
            return -1;
        }
    }

    v4l2_buf_type o_type;
    o_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (ioctl(this->m_fd, VIDIOC_STREAMON, &o_type))
    {
        return -1;
    }

    return 0;
}

int QVideoDevice::stopCapturing()
{
    v4l2_buf_type o_type;
    o_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (ioctl(this->m_fd, VIDIOC_STREAMOFF, &o_type))
    {
        return -1;
    }
    return 0;
}

int QVideoDevice::uninitDevice()
{
    if (m_myBuffers != NULL)
    {
        for (unsigned int i = 0 ; i < this->m_nBuffers ; i++)
        {
            if (munmap(this->m_myBuffers[i].pStart,this->m_myBuffers[i].length) == -1)
            {
                return -1;
            }
        }
        free(this->m_myBuffers);
    }
    return 0;
}

int QVideoDevice::getFrame(void **_framebuf, size_t *_len)
{
    v4l2_buffer o_queue;
    CLEAR(o_queue);
    //qDebug()<<"Create queue";
    o_queue.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    //qDebug()<<"Set type v4l2 buffer";
    o_queue.memory = V4L2_MEMORY_MMAP;
    //qDebug()<<"Set memory type v4l2 buffer";
    if (ioctl(this->m_fd, VIDIOC_DQBUF, &o_queue))
    {
        qDebug()<<"DQBUF error";
        return -1;
    }
    //qDebug()<<"Open OK";
    *_framebuf = this->m_myBuffers[o_queue.index].pStart;
    *_len = this->m_myBuffers[o_queue.index].length;
    //qDebug() << "Get into queue";
    this->m_index = o_queue.index;
    return 0;
}

int QVideoDevice::ungetFrame()
{
    if (this->m_index != -1)
    {
        v4l2_buffer o_queue;
        CLEAR(o_queue);

        o_queue.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        o_queue.memory = V4L2_MEMORY_MMAP;
        o_queue.index = this->m_index;

        if (ioctl(this->m_fd, VIDIOC_QBUF, &o_queue))
        {
            return -1;
        }
        return 0;
    }
    return -1;
}
