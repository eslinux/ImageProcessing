#include <QtGui/QApplication>
#include <iostream>
#include <string>
#include "QFrmMain.h"

using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QFrmMain w;
    w.show();
    return a.exec();
}
