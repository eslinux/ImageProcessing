/********************************************************************************
** Form generated from reading UI file 'QFrmMain.ui'
**
** Created: Mon Dec 30 02:10:40 2013
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QFRMMAIN_H
#define UI_QFRMMAIN_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QFrmMain
{
public:
    QAction *action_Setting;
    QAction *action_Exit;
    QAction *action_Connect;
    QAction *action_Disconnect;
    QAction *action_Open_Com_Port;
    QWidget *centralWidget;
    QLabel *lblDisplay;
    QMenuBar *menuBar;
    QMenu *menu_File;

    void setupUi(QMainWindow *QFrmMain)
    {
        if (QFrmMain->objectName().isEmpty())
            QFrmMain->setObjectName(QString::fromUtf8("QFrmMain"));
        QFrmMain->resize(480, 370);
        QFrmMain->setStyleSheet(QString::fromUtf8(""));
        action_Setting = new QAction(QFrmMain);
        action_Setting->setObjectName(QString::fromUtf8("action_Setting"));
        action_Exit = new QAction(QFrmMain);
        action_Exit->setObjectName(QString::fromUtf8("action_Exit"));
        action_Connect = new QAction(QFrmMain);
        action_Connect->setObjectName(QString::fromUtf8("action_Connect"));
        action_Disconnect = new QAction(QFrmMain);
        action_Disconnect->setObjectName(QString::fromUtf8("action_Disconnect"));
        action_Open_Com_Port = new QAction(QFrmMain);
        action_Open_Com_Port->setObjectName(QString::fromUtf8("action_Open_Com_Port"));
        centralWidget = new QWidget(QFrmMain);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        lblDisplay = new QLabel(centralWidget);
        lblDisplay->setObjectName(QString::fromUtf8("lblDisplay"));
        lblDisplay->setGeometry(QRect(0, 0, 480, 360));
        lblDisplay->setStyleSheet(QString::fromUtf8(""));
        QFrmMain->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QFrmMain);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 480, 23));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        QFrmMain->setMenuBar(menuBar);

        menuBar->addAction(menu_File->menuAction());
        menu_File->addSeparator();
        menu_File->addAction(action_Connect);
        menu_File->addAction(action_Disconnect);
        menu_File->addSeparator();
        menu_File->addAction(action_Setting);
        menu_File->addSeparator();
        menu_File->addAction(action_Exit);

        retranslateUi(QFrmMain);

        QMetaObject::connectSlotsByName(QFrmMain);
    } // setupUi

    void retranslateUi(QMainWindow *QFrmMain)
    {
        QFrmMain->setWindowTitle(QApplication::translate("QFrmMain", "QFrmMain", 0, QApplication::UnicodeUTF8));
        action_Setting->setText(QApplication::translate("QFrmMain", "Setting", 0, QApplication::UnicodeUTF8));
        action_Exit->setText(QApplication::translate("QFrmMain", "E&xit", 0, QApplication::UnicodeUTF8));
        action_Connect->setText(QApplication::translate("QFrmMain", "Connect", 0, QApplication::UnicodeUTF8));
        action_Disconnect->setText(QApplication::translate("QFrmMain", "Disconnect", 0, QApplication::UnicodeUTF8));
        action_Open_Com_Port->setText(QApplication::translate("QFrmMain", "Open Com Port", 0, QApplication::UnicodeUTF8));
        lblDisplay->setText(QApplication::translate("QFrmMain", "No input image", 0, QApplication::UnicodeUTF8));
        menu_File->setTitle(QApplication::translate("QFrmMain", "&File", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QFrmMain: public Ui_QFrmMain {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QFRMMAIN_H
