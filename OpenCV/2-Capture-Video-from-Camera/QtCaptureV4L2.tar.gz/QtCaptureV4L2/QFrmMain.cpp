#include "QFrmMain.h"
#include "ui_QFrmMain.h"


QFrmMain::QFrmMain(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::QFrmMain)
{
    // Setup ui
    ui->setupUi(this);
    this->strDevName = CAMERA_DEVICE_NAME;

    // Create variables
    this->m_pp = (unsigned char*)malloc(CAMERA_FRAME_WIDTH*CAMERA_FRAME_HEIGHT*3*sizeof(char));
    this->m_qImage = new QImage(this->m_pp,CAMERA_FRAME_WIDTH,CAMERA_FRAME_HEIGHT, QImage::Format_RGB888);
    this->m_vd = new QVideoDevice(this,CAMERA_DEVICE_NAME);
    this->m_timer = new QTimer(this);
    //this->m_frmSetting = NULL;
    this->m_isCapture = false;

    // Init control
    this->initControl();

    // Create connect
    this->initConnect();

    // Init structures
    this->initStructures();

    //this->on_action_Connect_triggered();
}

QFrmMain::~QFrmMain()
{
    // Disconnect
    this->uninitConnect();
    // Stop capture camera
    if (this->m_isCapture)
    {
        this->m_vd->stopCapturing();
        this->m_vd->uninitDevice();
        this->m_vd->closeDevice();
    }
    // Delete pointers
    delete this->m_vd;
    delete this->m_qImage;
    delete this->m_timer;
    delete ui;
    //if (this->m_frmSetting != NULL)
        //delete this->m_frmSetting;
    //if (this->m_processImage != NULL)
        //delete this->m_processImage;
}

// Init connect
void QFrmMain::initConnect()
{
    connect(this->m_timer, SIGNAL(timeout()), this, SLOT(displayImage()));
    connect(ui->action_Exit, SIGNAL(triggered()), this, SLOT(close()));
}

// Uninit connect
void QFrmMain::uninitConnect()
{
    disconnect(this->m_timer, SIGNAL(timeout()), this, SLOT(displayImage()));
    disconnect(ui->action_Exit, SIGNAL(triggered()), this, SLOT(close()));
}

// Init structures
void QFrmMain::initStructures()
{
    this->m_mySetting.cameraFPS = CAMERA_FPS;
    this->m_mySetting.cameraFrameHeight = CAMERA_FRAME_HEIGHT;
    this->m_mySetting.cameraFrameWidth = CAMERA_FRAME_WIDTH;
    this->m_mySetting.cameraName = CAMERA_DEVICE_NAME;
    this->m_mySetting.cameraEncode = CAMERA_ENCODE;
}

// Start camera
int QFrmMain::startCamera(QString strCamDevName)
{
    if (this->m_vd->openDevice(strCamDevName) == -1)
    {
        QMessageBox::warning(this, ERROR_TITLE, ERROR_OPEN_DEVICE,
                             QMessageBox::Ok);
    }
    else if (this->m_vd->initDevice() == -1)
    {
        QMessageBox::warning(this, ERROR_TITLE, ERROR_INIT_DEVICE,
                             QMessageBox::Ok);
    }
    else if (this->m_vd->startCapturing() == -1)
    {
        QMessageBox::warning(this, ERROR_TITLE, ERROR_CAPTURE_CAMERA,
                             QMessageBox::Ok);
    }
    else
    {
        this->m_timer->start(1000/this->m_mySetting.cameraFPS);
        this->m_isCapture = true;
        ui->action_Disconnect->setEnabled(true);
        ui->action_Connect->setEnabled(false);
        return 0;
    }
    return -1;
}

// Init control
void QFrmMain::initControl()
{
    // Set window title
    this->setWindowTitle(APPLICATION_TITLE);

    // Set size application
    this->resize(APPLICATION_WIDTH, APPLICATION_HEIGHT);

    // Set layout
    //ui->centralWidget->setLayout(ui->mainLayout);

    // Set center text in label and label border
    //ui->lblDisplay->setAlignment(Qt::AlignCenter);
    /*ui->lblDisplay->setStyleSheet(tr("margin:2px;")+
                                  tr("font:bold 14px;")+
                                  tr("color:red;")+
                                  tr("border-style: solid;")+
                                  tr("border-width: 1px;")+
                                  tr("border-color: green;"));
                                  */

    // Enable and disable actions
    ui->action_Connect->setEnabled(true);
    ui->action_Disconnect->setEnabled(false);
    ui->action_Setting->setEnabled(true);
    ui->action_Exit->setEnabled(true);
}

// Show error
void QFrmMain::displayError(QString err)
{
    QMessageBox::warning(this, ERROR_TITLE, err,QMessageBox::Ok);
}

// Display image
void QFrmMain::displayImage()
{
    this->m_rs = this->m_vd->getFrame((void**)&this->m_p, &this->m_len);
    //qDebug()<<"Get frame";
    //this->m_processImage->convertYUV2RGBBuffer(this->m_p,this->m_pp,CAMERA_FRAME_WIDTH,CAMERA_FRAME_HEIGHT);
    //Debug()<<"Convert";
    this->m_qImage->loadFromData((uchar*)this->m_p,CAMERA_FRAME_WIDTH*CAMERA_FRAME_HEIGHT*3*sizeof(char));
    //qDebug()<<"Capture !";
    IplImage *iplImg;
    CvMat cvmat = cvMat(480, 640, CV_8UC3, (void*)this->m_p);
    iplImg = cvDecodeImage(&cvmat,1);
    cvSaveImage("image.jpg",iplImg,0);
    // Show image
    QImage o_qImage = this->m_qImage->scaled(ui->lblDisplay->width(),
                                             ui->lblDisplay->height(),
                                             Qt::IgnoreAspectRatio);
    ui->lblDisplay->setPixmap(QPixmap::fromImage(o_qImage,Qt::AutoColor));


    //qDebug()<<"Show image";
    this->m_rs = this->m_vd->ungetFrame();
    //qDebug() << "Unget frame";
}

// Open form setting
void QFrmMain::on_action_Setting_triggered()
{
    //this->m_frmSetting = new QFrmSetting();
   // this->m_frmSetting->setWindowTitle(FORM_SETTING_TITLE);
    //this->m_frmSetting->setSetting(this->m_mySetting);
    //if (this->m_frmSetting->exec() == 1)
    //{
       // this->m_frmSetting->getSetting(&this->m_mySetting);
    //}
}

void QFrmMain::on_action_Connect_triggered()
{

        this->strDevName = this->m_mySetting.cameraName;
        // Start camera
        if (this->startCamera(this->strDevName) == -1)
        {
            QMessageBox::warning(this, ERROR_TITLE, ERROR_OPEN_DEVICE, QMessageBox::Ok);
        }
        qDebug()<<"Start camera sucessfull!";

}

void QFrmMain::on_action_Disconnect_triggered()
{
    ui->action_Connect->setEnabled(true);
    ui->action_Setting->setEnabled(true);
    ui->action_Disconnect->setEnabled(false);
    this->m_timer->stop();
    // Stop capture camera
    if (this->m_isCapture)
    {
        this->m_vd->stopCapturing();
        this->m_vd->uninitDevice();
        this->m_vd->closeDevice();
    }
}
