#ifndef QVIDEODEVICE_H
#define QVIDEODEVICE_H

#include <QObject>

/* C++ language in unix header files */
#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <linux/videodev2.h>


/* Qt header files */
#include <QDebug>
#include <QString>
#include <QTimer>
#include <QImage>
#include <QMessageBox>
#include <QLabel>
#include <QGroupBox>
#include <QScrollArea>

/* Defines camera */
#define CAMERA_DEVICE_NAME "/dev/video0"
#define CAMERA_FRAME_WIDTH 640
#define CAMERA_FRAME_HEIGHT 480
#define CAMERA_FPS  24
#define CAMERA_ENCODE "MPEG"

/* Struct myBuffer using QVideoDevice class */
struct myBufferVideo
{
    void *pStart;
    size_t length;
};

/* Struct Application setting */
struct mySetting
{
    QString cameraName;
    int cameraFPS;
    int cameraFrameHeight;
    int cameraFrameWidth;
    QString cameraEncode;
};


/* Macro */
#define CLEAR(x) memset(&(x),0,sizeof(x))

class QVideoDevice : public QObject
{
    Q_OBJECT
public:
    explicit QVideoDevice(QObject *parent = 0, QString _devName = 0);
    int openDevice(QString strDevName);
    int closeDevice();
    int initDevice();
    int startCapturing();
    int stopCapturing();
    int uninitDevice();
    int initMMap();
    int getFrame(void **,size_t*);
    int ungetFrame();
private:
    QString         m_strDeviceName;
    int             m_fd;
    int             m_index;
    myBufferVideo*  m_myBuffers;
    unsigned int    m_nBuffers;
};

#endif // QVIDEODEVICE_H
