#ifndef QFRMMAIN_H
#define QFRMMAIN_H

#include <QMainWindow>
#include "QVideoDevice.h"

#include "opencv/cv.h"
#include "opencv/highgui.h"

/* Defines application */
#define APPLICATION_TITLE tr("Camera Capture V4L2")
#define APPLICATION_WIDTH 480
#define APPLICATION_HEIGHT 360

/* Defines message */
#define ERROR_TITLE tr("Error !")
#define ERROR_OPEN_DEVICE tr("Open device failed.")
#define ERROR_INIT_DEVICE tr("Init device failed.")
#define ERROR_CAPTURE_CAMERA tr("Start capture failed.")

namespace Ui {
    class QFrmMain;
}

class QFrmMain : public QMainWindow
{
    Q_OBJECT

public:
    explicit QFrmMain(QWidget *parent = 0);
    ~QFrmMain();
    int startCamera(QString strCamDevName);
    void initConnect();
    void uninitConnect();
    void initControl();
    void initStructures();

private:
    Ui::QFrmMain *ui;
    QImage* m_qImage;
    QTimer* m_timer;
    QVideoDevice* m_vd;
    QString strDevName;

    int     m_rs;
    uchar*  m_pp;
    uchar*  m_p;
    bool    m_isCapture;
    unsigned int m_len;
    struct mySetting m_mySetting;
    //uint32_t tinc;

private slots:
    void on_action_Disconnect_triggered();
    void on_action_Connect_triggered();
    void on_action_Setting_triggered();
    void displayError(QString err);
    void displayImage();
};

#endif // QFRMMAIN_H
